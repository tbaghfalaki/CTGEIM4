library(TMixClust)
Y=best_clust_yeast_obj$ts_data

time=c(0,24,48,63,87)
genename=c("YBR034C", "YBR040W", "YBR067C", "YBR085CA", "YBR099C", "YBR291C",
           "YBR294W", "YCL025C", "YCL055W", "YCR005C", "YCR089W", "YDL022W",
           "YDL131W", "YDL174C", "YDL182W", "YDL184C", "YDR034C", "YDR072C",
           "YDR124W", "YDR234W", "YDR342C", "YDR343C", "YDR345C", "YDR461W",
           "YDR497C", "YDR502C", "YDR508C", "YDR516C", "YDR545W", "YEL011W",
           "YEL063C", "YEL065W", "YEL071W", "YER026C", "YER044C", "YER053CA",
           "YER091C", "YER150W", "YFL014W", "YFR030W", "YFR053C", "YGL032C",
           "YGL055W", "YGL062W", "YGL077C", "YGL113W", "YGL125W", "YGL255W",
           "YGR055W", "YGR065C", "YGR109WA", "YGR109WB", "YGR159C", "YGR188C",
           "YHL016C", "YHR053C", "YHR055C", "YHR094C", "YIL048W", "YIL080W",
           "YIL082W", "YIL082WA", "YIL108W", "YIL169C", "YJL007C", "YJL116C",
           "YJL130C", "YJL171C", "YJR010W", "YJR073C", "YJR137C", "YKL001C",
           "YKL008C", "YKL053W", "YKL071W", "YKL109W", "YKL128C", "YKR028W",
           "YKR042W", "YLR023C", "YLR091W", "YLR180W", "YLR220W", "YLR303W",
           "YLR395C", "YML047C", "YML089C", "YML100W", "YMR011W", "YMR096W",
           "YMR105C", "YMR186W", "YMR305C", "YMR318C", "YNL002C", "YNL036W",
           "YNL104C", "YNL112W", "YNL142W", "YNL145W", "YNL192W", "YNL208W",
           "YNL274C", "YNL279W", "YNR044W", "YNR050C", "YOL002C", "YOL049W",
           "YOL058W", "YOL123W", "YOL136C", "YOR204W", "YOR273C", "YOR298CA",
           "YOR303W", "YOR375C", "YPL061W", "YPL072W", "YPL135W", "YPL192C",
           "YPL226W", "YPL240C", "YPL265W", "YPL280W", "YPR159W")

RESULTS1=CTGE_IM4_un(mExpression=Y,time=time, maxcluster=6,
                     niter=1000, nburnin=500, nthin=1,
                     nchains=1, tau0=1, varsigma0=1, vartheta0=1, genename=genename)

PSM_plot(RESULTS1$PSM)

Cluster_Plot(mExpression=Y,time,RESULTS1$MPEAR,Some=TRUE)






