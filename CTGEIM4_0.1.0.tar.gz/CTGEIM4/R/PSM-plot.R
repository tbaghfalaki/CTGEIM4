#' PSM_plot function
#'
#'
#' @description
#' Return complex Heatmap for the posterior similarity matrix of CTGE-IM4.
#'
#'
#'
#' @param DIS The posterior similarity matrix.
#'
#'
#' @return
#' Complex Heatmap for the posterior similarity matrix.
#'
#'
#' @author Taban Baghfalaki.
#'
#' @references
#' T. Baghfalaki, M. Ganjali. (2021). Clustering time-course gene expression data  using  an infinite mixture model prior for marginal model. *Submitted*.
#'
#' @example inst/examplePSM-plot.R
#'
#' @md
#' @export

PSM_plot=function(DIS){

 library(ComplexHeatmap);library(circlize)

A=rep("",length(DIS[1,]))
Tab=round(seq(1,length(DIS[1,]),length=10))

A[Tab]=Tab

Heatmap(DIS, name = " ", row_order = order(as.numeric(gsub("row", "", rownames(DIS)))),
        column_order = order(as.numeric(gsub("column", "", colnames(DIS)))),
        column_labels =A,row_labels =A,row_title_side = "left",
        row_names_gp = gpar(fontsize = 7),
        row_names_side ="left",row_title="Gene ID",
        column_names_gp = gpar(fontsize = 7),
        column_names_side ="top",column_title="Gene ID",
        col = colorRamp2(c(0,.5,1),c("mistyrose", "white", "lightskyblue")))
}

