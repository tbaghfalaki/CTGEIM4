#' CTGEIM4 Package
#'
#'
#' @description
#' Run a Gibbs sampler for clustering time-course gene expression data  using  an infinite mixture model prior for marginal model.
#'
#'
#' @docType package
#'
#' @keywords CTGE_IM4, PSM_plot, Cluster_Plot
#'
#' @author Taban Baghfalaki \email{t.baghfalaki@gmail.com}, \email{t.baghfalaki@modares.ac.ir}
#'
#' @references
#' T. Baghfalaki, M. Ganjali. (2021). Clustering time-course gene expression data  using  an infinite mixture model prior for marginal model. *Submitted*.
#'
#' @name CTGEIM4
#'
NULL
