#' CTGE_IM4_un function
#'
#'
#' @description
#' Run a Gibbs sampler for clustering time-course gene expression data (unequally spaced time intervals) using  an infinite mixture model prior for marginal model.
#'
#'
#' @details
#' Run a Gibbs sampler using jags.
#'
#'
#' @param mExpression a gene expression matrix with n columns (length of time vector) and G rows (number of genes).
#' @param time time vector specifies the time points of measurements.
#' @param maxcluster Maximum number of clusters.
#' @param tau0 Initial value for tau  (Default is tau0=1).
#' @param vartheta0 Initial value for vartheta  (Default is vartheta0=1).
#' @param varsigma0 Initial value for varsigma0 (Default is varsigma0=1).
#' @param niter Number of iterations for the Gibbs sampler.
#' @param burnin Number of burn-in iterations.
#' @param nthin The lag of the iterations used for the posterior analysis is defined (or thinning rate).
#' @param nchains Number of Markov chains, when nchains>1, the function calculates the Gelman-Rubin convergence statistic, as modified by Brooks and Gelman (1998).
#' @param genename Name of genes.
#'
#'
#' @return
#' - Gene: The name of the genes.
#' - MBINDER: The labels of the clusters based on Minimizing Binder's loss.
#' - MPEAR: The labels of the clusters based on Maximum Posterior Expected Adjusted Rand (MPEAR).
#' - PSM: The posterior similarity matrix.
#'
#'
#' @author Taban Baghfalaki.
#'
#' @references
#' T. Baghfalaki, M. Ganjali. (2021). Clustering time-course gene expression data  using  an infinite mixture model prior for marginal model. *Submitted*.
#'
#' @example inst/exampleCTGE-IM4.R
#'
#' @md
#' @export

CTGE_IM4_un=function(mExpression,time=time, maxcluster=maxcluster, niter=100, nburnin=50, nthin=2, nchains=1, tau0=1, varsigma0=1, vartheta0=1, genename=1:length(mExpression[,1])){
library(R2jags);library(mcclust)
  equals=function(a){
    z=0
    if(a[1]==a[2])(z=1)
    ;z
  }

  sink("model.file.txt")
  cat("model{
 rho ~ dunif(-1,1)

tau[1:m,1:m]<-inverse(Cov[1:m,1:m])
 for(j in 1:m){
	for(k in 1:m){
	   Cov[j,k] <-sigma*exp(-((time[j]-time[k])^2)/2*ellv)
	   }}


for(i in 1:n){
  Y[i,1:m]~dmnorm(B[i,1:m],tau[1:m,1:m])
}
tau11~dgamma(0.01,0.01)
sigma<-1/tau11
ellv~dgamma(0.01,0.01)

for ( j in 1:n) {
    for (k in 1:m) {
      B[j,k]<- vartheta1[latent[j],k]
    }}
  for (i in 1:n) {
    latent[i]~dcat(pi[1:L1])
  }
  pi[1]<-r[1]
  for ( j in 2:(L1-1)) {
    log(pi[j])<-log(r[j])+sum(R1[j,1:(j-1)])
    for ( l in 1:(j-1)) {
      R1[j,l]<-log(1-r[l])
    }}
  pi[L1]<-1-sum(pi[1:(L1-1)])
  for ( j in 1:L1) {
    r[j]~dbeta(1,varsigma)
  }
  for ( i in 1:L1) {
    vartheta1[i,1:m]~dmnorm(zero[1:m],Sab[1:m,1:m])
  }
  Sab[1:m,1:m] ~ dwish(Omega[1:m,1:m], m)
  varcovab[1:m,1:m] <- inverse(Sab[,])

  varsigma~dunif(0,10)
for(i in 1:n){
for(j in 1:n){
Dis[i,j]<-equals( latent[i], latent[j])
}}

}"
,fill = TRUE)
  sink()


  Y=mExpression
  n=dim(Y)[1]
  m=dim(Y)[2]
  L1=maxcluster;Omega=diag(m);zero=rep(0,m)
  data <- list ("Y","n","m","Omega", "L1","zero","time")
  inits <- function(){
    list(tau11=tau0,ellv=vartheta0, varsigma=varsigma0,Sab=Omega)
  }

  parameters <- c("latent")
  sim <- jags(data, inits, parameters,n.chains=nchains,n.thin=nthin,
              n.iter=niter, n.burnin=nburnin,model.file="model.file.txt")

  Z=sim[[2]]$sims.list$latent
  M=floor((niter-nburnin)/nthin)
  DIS=array(0,c(n,n,M))
  for(k in 1:M){
    for(i in 1:n){
      for(j in 1:n){
        DIS[i,j,k]<-equals(c(Z[k,i], Z[k,j]))
      }}}

  PSM=apply(DIS,c(1,2),mean)
  colnames(PSM)=genename
  rownames(PSM)=genename



  mbind2 <- minbinder(PSM)$cl
  mpear2 <- maxpear(PSM)$cl


  Reslast= list(Gene=genename, MBINDER=mbind2, MPEAR=mpear2, PSM=PSM)

  ;Reslast
}
