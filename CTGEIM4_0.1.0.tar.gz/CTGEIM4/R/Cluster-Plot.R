#' Cluster_Plot function
#'
#'
#' @description
#' The time-course profiles for the genes of each cluster which detected by CTGE-IM4.
#'
#'
#'
#' @param mExpression a gene expression matrix with n columns (length of time vector) and G rows (number of genes).
#' @param time time vector specifies the time points of measurements.
#' @param labels The identified clusters given in data based on MBINDER or MPEAR.
#' @param Some=FALSE FALSE: The time-course profiles of each cluster is given in a separate panel. TRUE: The time-course profiles of all clusters is given in a panel.
#'
#' @return
#' Return the time-course profiles for the genes of each cluster which detected by CTGE-IM4.
#'
#'
#' @author Taban Baghfalaki.
#'
#' @references
#' T. Baghfalaki, M. Ganjali. (2021). Clustering time-course gene expression data  using  an infinite mixture model prior for marginal model. *Submitted*.
#'
#' @example inst/exampleCluster-plot.R
#'
#' @md
#' @export


Cluster_Plot=function(mExpression=mExpression,time=time,labels=labels,Some=TRUE){

    Y=mExpression
    n=length(Y[,1])
    index=1:n
    indexnew=list()
    Num=dim(table(labels))
    for(j in 1:Num){
        indexnew[[j]]=index[labels==j]
    }



    if(Some==TRUE){
        if(Num<7)(par(mfrow=c(2,3)))
        if(Num>6 & Num<11)(par(mfrow=c(2,5)))
        if(Num>10)(par(mfrow=c(3,4)))}
    if(Some==FALSE){ mfrow=c(1,1)}



    par(bg="white", mar=c(2.5, 2.5, 2.5, 0.25))
    for(kkk in 1:Num){
        plot(time,Y[indexnew[[kkk]][1],],type="n",ylim=c(min(Y),max(Y)),
             ylab="Expression level",main=paste0("Cluster ", kkk),xlab="Time", xaxt="n", yaxt="n")
        axis(side=1, time, tcl=-0.2, labels=FALSE)
        Yaxis=round(seq(min(Y),max(Y),length=6))
        axis(side=2, Yaxis, tcl=-0.2, labels=FALSE)
        mtext(Yaxis, side=2, las=1, at=Yaxis, line=0.2, col="blue", cex=0.6)
        mtext(time, side=1, las=1, at=time, line=0.2, col="blue", cex=0.6)
if(length(indexnew[[kkk]])>1){
        for(i in indexnew[[kkk]]){
            lines(time,Y[i,],type="l",col="antiquewhite")
            lines(time,apply(Y[indexnew[[kkk]],],2,mean),
                  type="l",lwd=2,col="darkgoldenrod1")
        }
}


    if(length(indexnew[[kkk]])==1){
        for(i in indexnew[[kkk]]){
            lines(time,Y[i,],type="l",col="antiquewhite")
            lines(time,Y[i,],
                  type="l",lwd=2,col="darkgoldenrod1")
        }
    }
}


}

